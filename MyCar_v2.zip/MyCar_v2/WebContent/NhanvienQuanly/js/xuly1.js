  $(document).ready( function () {
	  $('.dangxuat').click(function(){
		  session.invalidate();
	  });
  });
