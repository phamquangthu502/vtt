package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class XeDoitacKygui {
	private int id;
	private int trangthai;
	private Date ngaykt;
	private Xe xe;

	public XeDoitacKygui() {
		super();
	}

	public XeDoitacKygui(int id, int trangthai, Date ngaykt, Xe xe) {
		super();
		this.id = id;
		this.trangthai = trangthai;
		this.ngaykt = ngaykt;
		this.xe = xe;
	}

	public XeDoitacKygui(int id, int trangthai, String ngaykt, Xe xe) throws ParseException {
		super();
		Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(ngaykt);
		this.id = id;
		this.trangthai = trangthai;
		this.ngaykt = date1;
		this.xe = xe;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTrangthai() {
		return trangthai;
	}

	public void setTrangthai(int trangthai) {
		this.trangthai = trangthai;
	}

	public Date getNgaykt() {
		return ngaykt;
	}

	public void setNgaykt(Date ngaykt) {
		this.ngaykt = ngaykt;
	}

	public Xe getXe() {
		return xe;
	}

	public void setXe(Xe xe) {
		this.xe = xe;
	}

}
