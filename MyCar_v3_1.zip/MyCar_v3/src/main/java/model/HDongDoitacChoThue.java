package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class HDongDoitacChoThue {
	private int id;
	private Date ngaybd;
	private Date ngaykt;
	private int trangthai;
	private float tongtien;
	private String ghichu;
	private Doitac doitac;
	private Nhanvien nhanvien;
	private List<XeDathueDoitac> listXedathue;
	private Date ngaytao;

	public HDongDoitacChoThue() {
		super();
	}

	public HDongDoitacChoThue(int id, Date ngaybd, Date ngaykt, int trangthai, float tongtien, String ghichu,
			Doitac doitac, Nhanvien nhanvien, List<XeDathueDoitac> listXedathue, Date ngaytao) {
		super();
		this.id = id;
		this.ngaybd = ngaybd;
		this.ngaykt = ngaykt;
		this.trangthai = trangthai;
		this.tongtien = tongtien;
		this.ghichu = ghichu;
		this.doitac = doitac;
		this.nhanvien = nhanvien;
		this.listXedathue = listXedathue;
		this.ngaytao = ngaytao;
	}
	
	public HDongDoitacChoThue(int id, String ngaybd, String ngaykt, int trangthai, float tongtien, String ghichu,
			Doitac doitac, Nhanvien nhanvien) throws ParseException {
		super();
		this.id = id;
		this.ngaybd = new SimpleDateFormat("dd/MM/yyyy").parse(ngaybd);
		this.ngaykt = new SimpleDateFormat("dd/MM/yyyy").parse(ngaykt);
		this.trangthai = trangthai;
		this.tongtien = tongtien;
		this.ghichu = ghichu;
		this.doitac = doitac;
		this.nhanvien = nhanvien;
	}
	
	public HDongDoitacChoThue(String ngaybd, String ngaykt, int trangthai, float tongtien, String ghichu,
			Doitac doitac, Nhanvien nhanvien, List<XeDathueDoitac> listXedathue) throws ParseException {
		super();
		this.ngaybd = new SimpleDateFormat("dd/MM/yyyy").parse(ngaybd);
		this.ngaykt = new SimpleDateFormat("dd/MM/yyyy").parse(ngaykt);
		this.trangthai = trangthai;
		this.tongtien = tongtien;
		this.ghichu = ghichu;
		this.doitac = doitac;
		this.nhanvien = nhanvien;
		this.listXedathue = listXedathue;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getNgaybd() {
		return ngaybd;
	}

	public void setNgaybd(Date ngaybd) {
		this.ngaybd = ngaybd;
	}
	public void setNgaybd(String ngaybd) throws ParseException {
		Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(ngaybd);
		this.ngaybd = date1;
	}

	public Date getNgaykt() {
		return ngaykt;
	}

	public void setNgaykt(Date ngaykt) {
		this.ngaykt = ngaykt;
	}
	
	public void setNgaykt(String ngaykt) throws ParseException {
		Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(ngaykt);
		this.ngaykt = date1;
	}

	public int getTrangthai() {
		return trangthai;
	}

	public void setTrangthai(int trangthai) {
		this.trangthai = trangthai;
	}

	public float getTongtien() {
		return tongtien;
	}

	public void setTongtien(float tongtien) {
		this.tongtien = tongtien;
	}

	public String getGhichu() {
		return ghichu;
	}

	public void setGhichu(String ghichu) {
		this.ghichu = ghichu;
	}

	public Doitac getDoitac() {
		return doitac;
	}

	public void setDoitac(Doitac doitac) {
		this.doitac = doitac;
	}

	public Nhanvien getNhanvien() {
		return nhanvien;
	}

	public void setNhanvien(Nhanvien nhanvien) {
		this.nhanvien = nhanvien;
	}

	public List<XeDathueDoitac> getListXedathue() {
		return listXedathue;
	}

	public void setListXedathue(List<XeDathueDoitac> listXedathue) {
		this.listXedathue = listXedathue;
	}

	public Date getNgaytao() {
		return ngaytao;
	}

	public void setNgaytao(Date ngaytao) {
		this.ngaytao = ngaytao;
	}

	@Override
	public String toString() {
		return "HDongDoitacChoThue [ngaybd=" + ngaybd + ", ngaykt=" + ngaykt + ", trangthai=" + trangthai
				+ ", tongtien=" + tongtien + ", ghichu=" + ghichu + ", doitac=" + doitac + ", nhanvien=" + nhanvien
				+ ", listXedathue=" + listXedathue + ", ngaytao=" + ngaytao + "]";
	}

}
