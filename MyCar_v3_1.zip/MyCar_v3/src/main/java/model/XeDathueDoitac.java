package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class XeDathueDoitac {
	private int id;
	private Date ngaytra;
	private float dongia;
	private String tinhtrang;
	private int trangthai;
	private XeDoitacKygui xe;

	public XeDathueDoitac() {
		super();
	}

	public XeDathueDoitac(int id, Date ngaytra, float dongia, String tinhtrang, int trangthai, XeDoitacKygui xe) {
		super();
		this.id = id;
		this.ngaytra = ngaytra;
		this.dongia = dongia;
		this.tinhtrang = tinhtrang;
		this.trangthai = trangthai;
		this.xe = xe;
	}

	public XeDathueDoitac(int id, String ngaytra, float dongia, String tinhtrang, int trangthai, XeDoitacKygui xe)
			throws ParseException {
		super();
		Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(ngaytra);
		this.id = id;
		this.ngaytra = date1;
		this.dongia = dongia;
		this.tinhtrang = tinhtrang;
		this.trangthai = trangthai;
		this.xe = xe;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getNgaytra() {
		return ngaytra;
	}

	public void setNgaytra(String ngaytra) throws ParseException {
		Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(ngaytra);
		this.ngaytra = date1;
	}

	public float getDongia() {
		return dongia;
	}

	public void setDongia(float dongia) {
		this.dongia = dongia;
	}

	public String getTinhtrang() {
		return tinhtrang;
	}

	public void setTinhtrang(String tinhtrang) {
		this.tinhtrang = tinhtrang;
	}

	public int getTrangthai() {
		return trangthai;
	}

	public void setTrangthai(int trangthai) {
		this.trangthai = trangthai;
	}

	public XeDoitacKygui getXe() {
		return xe;
	}

	public void setXe(XeDoitacKygui xe) {
		this.xe = xe;
	}

}
