package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.CallableStatement;

import model.Doitac;
import model.Xe;
import model.XeDoitacKygui;

public class XeDoitacKyguiDAO extends DAO{

	public XeDoitacKyguiDAO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public List<XeDoitacKygui> getDtXeDtKygui(String dong){
		Doitac dt = null;
		Xe xe = null;
		XeDoitacKygui xekygui = null;
		List<XeDoitacKygui> listXeDt = new ArrayList<XeDoitacKygui>();
		
		String sql = "{call searchDtByXe(?)}";
		
		try {
			CallableStatement cs = (CallableStatement) con.prepareCall(sql);
			cs.setString(1, dong);
			ResultSet rs = cs.executeQuery();

			while (rs.next()) {
				dt = new Doitac();
				xe = new Xe();
				xekygui = new XeDoitacKygui();
				
				dt.setId(rs.getInt("iddoitac"));
				dt.setTrangthai(rs.getInt("trangthaidt"));
				dt.setTen(rs.getString("tendt"));
				dt.setDiachi(rs.getString("diachi"));
				dt.setDt(rs.getString("dt"));
				dt.setGhichu("");
				
				xe.setId(rs.getInt("idxe"));
				xe.setTen(rs.getString("tenxe"));
				xe.setBiebso(rs.getString("bienso"));
				xe.setDong(rs.getString("dong"));
				xe.setDoi(rs.getInt("doi"));
				xe.setMau(rs.getString("mau"));
				xe.setDt(dt);
				
				xekygui.setId(rs.getInt("idxekygui"));
				xekygui.setTrangthai(rs.getInt("trangthaixekygui"));
				xekygui.setXe(xe);
				
				listXeDt.add(xekygui);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listXeDt;
	}
	
	public List<XeDoitacKygui> searchXeDtKygui(int ids, String dongs){
		Xe xe = null;
		XeDoitacKygui xekygui = null;
		List<XeDoitacKygui> listXeDt = new ArrayList<XeDoitacKygui>();
		
		String sql = "{call searchXeByDt(?,?)}";
		
		try {
			CallableStatement cs = (CallableStatement) con.prepareCall(sql);
			cs.setInt(1, ids);
			cs.setString(2, dongs);
			ResultSet rs = cs.executeQuery();

			while (rs.next()) {
				xe = new Xe();
				xekygui = new XeDoitacKygui();
				
				xe.setId(rs.getInt("idxe"));
				xe.setTen(rs.getString("tenxe"));
				xe.setBiebso(rs.getString("bienso"));
				xe.setDong(rs.getString("dong"));
				xe.setDoi(rs.getInt("doi"));
				xe.setMau(rs.getString("mau"));
				
				xekygui.setId(rs.getInt("idxekygui"));
				xekygui.setTrangthai(rs.getInt("trangthaixekygui"));
				xekygui.setXe(xe);
				
				listXeDt.add(xekygui);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listXeDt;
	}

}
