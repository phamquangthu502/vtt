
	  $(document).ready( function () {
		  $('.dangxuat').click(function(){
			  alert('ok');
		  });
	  });
