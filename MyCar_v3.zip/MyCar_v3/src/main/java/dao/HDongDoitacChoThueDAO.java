package dao;

import java.sql.Date;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.CallableStatement;

import model.Doitac;
import model.HDongDoitacChoThue;
import model.Nhanvien;
import model.Xe;
import model.XeDathueDoitac;

public class HDongDoitacChoThueDAO extends DAO {

	public HDongDoitacChoThueDAO() {
		super();
	}

	public boolean luuHopDong(HDongDoitacChoThue hd) {
		boolean kq = true;
		
		String sqlthem = "INSERT INTO tbl_hdongdoitacchothue(ngaybd,ngaykt,trangthai,tongtien,ghichu,"
				+ "tbl_doitacid,tbl_nhanvienid) VALUES (?,?,?,?,?,?,?);";
		String sqlthemXedt = "INSERT INTO tbl_xedathuedoitac(dongia,tinhtrang,trangthai,"
				+ "tbl_xekyguiid,tbl_hdongdoitacthueid) VALUES (?,?,?,?,?);";

		try{
			//Statement.RETURN_GENERATED_KEYS trả về id mới thêm trong câu 'sqlthem'
			PreparedStatement preparedStatement = con.prepareStatement(sqlthem,Statement.RETURN_GENERATED_KEYS);
			con.setAutoCommit(false);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String date1=sdf.format(hd.getNgaybd() );
			String date2=sdf.format(hd.getNgaykt() );
			preparedStatement.setString(1, date1 );
			preparedStatement.setString(2, date2 );
			preparedStatement.setInt(3, hd.getTrangthai());
			preparedStatement.setFloat(4, hd.getTongtien());
			preparedStatement.setString(5, hd.getGhichu());
			preparedStatement.setInt(6, hd.getDoitac().getId());
			preparedStatement.setInt(7, hd.getNhanvien().getId());

			preparedStatement.executeUpdate();
			
			ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if(generatedKeys.next()){
                hd.setId(generatedKeys.getInt(1));
                System.out.println(generatedKeys.getInt(1));
                /*them xedathuedoitac*/
                for(XeDathueDoitac xedt: hd.getListXedathue()){
                	
                	System.out.println(xedt.getDongia()+"; "+xedt.getTinhtrang()+"; "+xedt.getTrangthai()
                	+"; "+xedt.getXe().getId()+"; "+hd.getId());
                	preparedStatement = con.prepareStatement(sqlthemXedt, Statement.RETURN_GENERATED_KEYS);
                	
                	preparedStatement.setFloat(1, xedt.getDongia());
                
                	preparedStatement.setString(2, xedt.getTinhtrang());       	
                	preparedStatement.setInt(3, xedt.getTrangthai());
                	
                	preparedStatement.setInt(4, xedt.getXe().getId());
                	preparedStatement.setInt(5, hd.getId());
                	
                	preparedStatement.executeUpdate();
                    generatedKeys = preparedStatement.getGeneratedKeys();
                    if(generatedKeys.next()){
                    	xedt.setId(generatedKeys.getInt(1));
                    }
                }
            }
			
			con.commit();
		}
		catch (SQLException e) {
			kq = false;
            try{
                con.rollback();
            }catch(Exception ex){
                kq = false;
                ex.printStackTrace();
            }
            e.printStackTrace();
		}
		finally {
			try{
                con.setAutoCommit(true);
            }catch(Exception e){
                kq = false;
                e.printStackTrace();
            }
		}
		return kq;
	}
	
	public Doitac getDt(int ma) {
		Doitac dtac = null;
		String sql = "{call getOneDt(?)}";
		try {
			CallableStatement cs = (CallableStatement) con.prepareCall(sql);
			cs.setInt(1, ma);
			ResultSet rs = cs.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				int trangthai = rs.getInt("trangthai");
				String ten = rs.getString("ten");
				String diachi = rs.getString("diachi");
				String dt = rs.getString("dt");
				String ghichu = "";
				if (rs.getString("ghichu") != null)
					ghichu = rs.getString("ghichu");
				dtac = new Doitac(id, trangthai, ten, diachi, dt, ghichu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dtac;
	}
	
	public Xe getXe(int ids) {

		Xe xe = null;
		String sql = "{call getOneXe(?)}";
		try {
			CallableStatement cs = (CallableStatement) con.prepareCall(sql);
			cs.setInt(1, ids);
			ResultSet rs = cs.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String ten = rs.getString("ten");
				String bienso = rs.getString("bienso");
				String dong = rs.getString("dong");
				int doi = rs.getInt("doi");
				String mau = rs.getString("mau");
				String ghichu = rs.getString("ghichu");
				xe = new Xe(id, ten, bienso, dong, doi,mau, ghichu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return xe;
	}
	
	public Nhanvien getNv(int ids) {

		Nhanvien nv = null;
		String sql = "{call getOneNv(?)}";
		try {
			CallableStatement cs = (CallableStatement) con.prepareCall(sql);
			cs.setInt(1, ids);
			ResultSet rs = cs.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String vt = rs.getString("vitri");
				String ten = rs.getString("ten");
				String ns = rs.getString("ngaysinh");
				String dt = rs.getString("dt");
				String email = rs.getString("email");

				nv = new Nhanvien(id, ten, ns, email, dt, vt);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return nv;
	}
	
	public List<HDongDoitacChoThue> listHD() throws ParseException{
		List<HDongDoitacChoThue> res = new ArrayList<>();
		String sql = "SELECT * FROM tbl_hdongdoitacchothue a WHERE trangthai=1;";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int id = rs.getInt("id");
				String ngaybd = rs.getString("ngaybd");
				String ngaykt = rs.getString("ngaykt");
				int trangthai = Integer.parseInt(rs.getString("trangthai"));
				float tongtien = Float.parseFloat(rs.getString("tongtien"));
				String ghichu = rs.getString("ghichu");

				int iddoitac = Integer.parseInt(rs.getString("tbl_doitacid"));
				Doitac dt = getDt(iddoitac);

				int idnv = Integer.parseInt(rs.getString("tbl_nhanvienid"));
				Nhanvien nv = getNv(idnv);

				res.add(new HDongDoitacChoThue(id, ngaybd, ngaykt, trangthai, tongtien, ghichu, dt, nv));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return res;
	}
	
	public boolean updateHd(int id) {
		boolean check = true;
		String sqlsua = "UPDATE `tbl_hdongdoitacchothue` SET `trangthai`=? WHERE `id`=?";
		try( PreparedStatement preparedStatement = con.prepareStatement(sqlsua)){
			preparedStatement.setInt(1, 2);
			preparedStatement.setInt(2, id);
			preparedStatement.executeUpdate();	
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			check = false;
		}
		return check;
	}

}
