package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.CallableStatement;

import model.Xe;

public class XeDAO extends DAO{

	public XeDAO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<String> getDong() {

		List<String> dongs = new ArrayList<String>();
		String sql = "SELECT DISTINCT dong FROM tbl_xe";
		try {
			CallableStatement cs = (CallableStatement) con.prepareCall(sql);
			ResultSet rs = cs.executeQuery();

			while (rs.next()) {
				String dong = rs.getString("dong");
				dongs.add(dong);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dongs;
	}
}
